package forms;

import org.openqa.selenium.winium.WiniumDriver;

public class CadastroDiaria {
	
	public void clicarBtnPesquisar(WiniumDriver driver) {
	
		driver.findElementById("btnPesquisar").click();
	}
	
	public void clicarBtnNovo(WiniumDriver driver) {
		driver.findElementById("btnNovo").click();
	}
	
	public void preencherTxtPesquisar(WiniumDriver driver) {
		driver.findElementById("1771396").sendKeys("TESTE");
	}
	
	public void clicarBtnSalvar(WiniumDriver driver) {
		driver.findElementById("btnSalvar").click();
	}
	
	public void clicarBtnCancelar(WiniumDriver driver) {
		driver.findElementById("btnCancelar").click();
	}
	
	public void preencherTitulo(WiniumDriver driver) {
		driver.findElementById("txtTitulo").sendKeys("TESTE");
	}
	
	public void preencherValor(WiniumDriver driver) {
		driver.findElementById("txtValor").sendKeys("50");
	}
	
	public void preencherQtdeDias(WiniumDriver driver) {
		driver.findElementById("txtQtdeDias").sendKeys("1");
	}
	
	public void clicarTpVeiculo(WiniumDriver driver) {
		driver.findElementByName("M�DIO").click();
	}
	
	public void clicarBtnOk(WiniumDriver driver) {
		driver.findElementById("btnOk").click();
	}
}
