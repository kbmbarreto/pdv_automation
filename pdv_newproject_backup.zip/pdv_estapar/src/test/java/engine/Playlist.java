package engine;

import org.openqa.selenium.winium.WiniumDriver;

import testcases.MenuAdmin;

public class Playlist {

	MenuAdmin menuAdmin = new MenuAdmin();
	
	public void executarPlaylist(WiniumDriver driver) {
	
		/***********************************************/
		//-------------MEN� ADMINISTRA��O--------------//
		/***********************************************/
		
		menuAdmin.novoCadastroDiaria(driver);
		menuAdmin.pesquisarCadastroDiaria(driver);
	}	
}