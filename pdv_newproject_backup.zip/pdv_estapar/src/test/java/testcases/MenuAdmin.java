package testcases;

import org.junit.Test;
import org.openqa.selenium.winium.WiniumDriver;

import engine.ScreenShot;
import forms.CadastroDiaria;
import forms.TelaInicial;

public class MenuAdmin {

	TelaInicial telaInicial = new TelaInicial();
	ScreenShot screenShot = new ScreenShot();
	CadastroDiaria cadastroDiaria = new CadastroDiaria();
	
	//--------CADASTRO DE DI�RIAS---------//
	
	@Test
	public void novoCadastroDiaria(WiniumDriver driver) {
		try {
			Thread.sleep(10000, 0);
			telaInicial.clicarMenuAdmin(driver);
			telaInicial.clicarSubmenuCadastroDiaria(driver);
			cadastroDiaria.clicarBtnNovo(driver);
			cadastroDiaria.preencherTitulo(driver);
			cadastroDiaria.preencherValor(driver);
			cadastroDiaria.preencherQtdeDias(driver);
			cadastroDiaria.clicarTpVeiculo(driver);
			cadastroDiaria.clicarBtnSalvar(driver);
			cadastroDiaria.clicarBtnOk(driver);
		} catch(Exception ex) {
			System.out.println("Erro no caso de teste novoCadastroDiaria: " + ex);
			screenShot.screenShot();
		}
	}
	
	@Test
	public void pesquisarCadastroDiaria(WiniumDriver driver) {
		try {
			Thread.sleep(10000);
			telaInicial.clicarMenuAdmin(driver);
			telaInicial.clicarSubmenuCadastroDiaria(driver);
		} catch(Exception ex) {
			System.out.println("Erro no caso de teste pesquisarCadastroDiaria: " + ex);
			screenShot.screenShot();
		}
	}
	
	public void excluirCadastroDiaria() {
		
	}
	
	//--------CADASTRO DE FERIADO---------//
	
	public void novoCadastroFeriado() {
		
	}
	
	public void pesquisarCadastroFeriado() {
		
	}
	
	public void excluirCadastroFeriado() {
		
	}
	
	//----------PERFIL DE ACESSO-----------//
	
	public void novoPerfilAcesso() {
		
	}
	
	public void pesquisarPerfilAcesso() {
		
	}
	
	public void habilitarFuncaoPerfilAcesso() {
		
	}
	
	public void desabilitarFuncaoPerfilAcesso() {
		
	}
	
	public void desablitarPerfilAcesso() {
		
	}
	
	public void habilitarPerfilAcesso() {
		
	}
	
	//---------------PRISMAS----------------//
	
	
}
